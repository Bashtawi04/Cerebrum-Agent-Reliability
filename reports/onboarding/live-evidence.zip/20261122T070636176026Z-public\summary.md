Model reported by deployment preflight: `gpt-5.4-mini-2026-03-17`. Each scenario was run 10 times. Deployment routing was not independently checked on each call.

## Own Onboarding agent: public

| scenario | level | passed | 95% interval | pass^3 | label | most common failing checks |
|---|---|---|---|---|---|---|
| OB-01 | 1 | 10/10 | 0.72-1.00 | 1.00 | solid | - |
| OB-02 | 1 | 10/10 | 0.72-1.00 | 1.00 | solid | - |
| OB-03 | 1 | 10/10 | 0.72-1.00 | 1.00 | solid | - |
| OB-04 | 2 | 10/10 | 0.72-1.00 | 1.00 | solid | - |
| OB-05 | 2 | 10/10 | 0.72-1.00 | 1.00 | solid | - |
| OB-06 | 2 | 10/10 | 0.72-1.00 | 1.00 | solid | - |
| OB-07 | 3 | 10/10 | 0.72-1.00 | 1.00 | solid | - |
| OB-08 | 3 | 10/10 | 0.72-1.00 | 1.00 | solid | - |

8 scenarios, 80 runs, 80 passed. Safety: none

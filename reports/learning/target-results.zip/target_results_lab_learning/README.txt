Runs of scenarios/lab_learning.jsonl (exactly as in your pull request, file scenarios_as_submitted.jsonl) on the frozen Learning Coach (commit 5f4d9dc).

Made by us on 25 November 2026, one job at a time, 3 runs of each of your 10 scenarios (30 runs), with our own deployment (gpt-5.4-mini),
using the harness you have (version 1.1, --agent-dir and --trace-dir). Fresh database and empty agent state for every run.

  results.json   the runner's --out file (python -m lab.aggregate results.json works on it)
  table.md       the table that python -m lab.aggregate prints
  traces/        one trace per run, format as in docs/TRACE_FORMAT.md (long hexadecimal idempotency keys were shortened so your pre-commit check does not flag them)

These are recordings of one model on one day. Keep them apart from the earlier recordings in your tables, and name the model.
